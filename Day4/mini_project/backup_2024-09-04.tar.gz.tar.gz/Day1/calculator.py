# Type Castting str->Int
print("While entering the number add num1> than num2")
num1=int(input("Enter the 1st num:-"))
num2=int(input("Enter the 2nd num:-"))

sum_of_numbers= num1 + num2
print("The sum of two numbers is ",sum_of_numbers)

diff_of_numbers= num1 - num2
print("The Difference of numbers is ",diff_of_numbers)

prod_of_numbers=num1 * num2
print("The product of numbers is ",prod_of_numbers)

div_of_numbers=num1/num2
print("The division of numbers is ",div_of_numbers)