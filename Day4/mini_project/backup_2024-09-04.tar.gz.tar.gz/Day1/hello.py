# helloprogram

x=("Hello world")
print(x)

# taking input and storing in variable 

y=input("Enter your Domain :-")
print("Your Domain is:-" + y)