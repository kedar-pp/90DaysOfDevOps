# convert any text in lower case

day_of_week=input("Enter the Day of week: ").lower()
print(day_of_week)

# convert any text in upper case

name_in_lower=input("Enter the Name in lower case: ").upper()
print(name_in_lower)

# conditions in loops

day=input("Enter the day :-")
print(day)

if day=="saturday" or day=="sunday":
    print("I will learn Live DevOps")
else:
    print("I will practice DevOps")